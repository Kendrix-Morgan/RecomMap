package jp.ac.jec.cm0135.recommap;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import androidx.room.Room;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class SpotEditActivity extends AppCompatActivity {
    private EditText nameInput;
    private EditText commentInput;
    private RatingBar ratingBar;
    private Spinner categorySpinner;
    private Button updateButton;
    private Button deleteButton;
    private AppDatabase db;
    private Item currentItem;
    private GoogleMap map;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_spot_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app.db")
                .allowMainThreadQueries().build();

        nameInput = findViewById(R.id.input_name);
        commentInput = findViewById(R.id.input_comment);
        ratingBar = findViewById(R.id.input_rating);
        categorySpinner = findViewById(R.id.input_category);
        updateButton = findViewById(R.id.button_update);
        deleteButton = findViewById(R.id.button_delete);

        // Set up category spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.category_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Get item data
        int itemId = getIntent().getIntExtra("item_id", -1);
        if (itemId != -1) {
            for (Item item : db.itemDao().getAll()) {
                if (item.id == itemId) {
                    currentItem = item;
                    break;
                }
            }
        }

        if (currentItem != null) {
            nameInput.setText(currentItem.name);
            commentInput.setText(currentItem.comment);
            ratingBar.setRating(currentItem.rating);
            int position = adapter.getPosition(currentItem.category);
            categorySpinner.setSelection(position);

            // Map setup (read-only)
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            if (mapFragment != null) {
                mapFragment.getMapAsync(googleMap -> {
                    map = googleMap;
                    LatLng location = new LatLng(currentItem.latitude, currentItem.longitude);
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 16));
                    map.addMarker(new MarkerOptions().position(location));
                });
            }
        }

        updateButton.setOnClickListener(v -> {
            currentItem.name = nameInput.getText().toString();
            currentItem.comment = commentInput.getText().toString();
            currentItem.rating = ratingBar.getRating();
            currentItem.category = categorySpinner.getSelectedItem().toString();
            db.itemDao().update(currentItem);
            finish();
        });

        deleteButton.setOnClickListener(v -> {
            db.itemDao().delete(currentItem);
            finish();
        });
    }
}