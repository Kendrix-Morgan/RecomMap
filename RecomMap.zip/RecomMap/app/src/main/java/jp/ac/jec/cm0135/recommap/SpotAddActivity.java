package jp.ac.jec.cm0135.recommap;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class SpotAddActivity extends AppCompatActivity {
    private EditText nameInput;
    private EditText commentInput;
    private RatingBar ratingBar;
    private Spinner categorySpinner;
    private Button submitButton;
    private AppDatabase db;
    private GoogleMap map;
    private LatLng selectedLocation = new LatLng(35.6985, 139.6980); // default JEC

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_spot_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app.db")
                .allowMainThreadQueries().build();

        nameInput = findViewById(R.id.input_name);
        commentInput = findViewById(R.id.input_comment);
        ratingBar = findViewById(R.id.input_rating);
        categorySpinner = findViewById(R.id.input_category);
        submitButton = findViewById(R.id.button_submit);

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.category_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Map setup
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(googleMap -> {
                map = googleMap;
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(selectedLocation, 16));
                MarkerOptions markerOptions = new MarkerOptions().position(selectedLocation);
                map.addMarker(markerOptions);
                map.setOnMapClickListener(latLng -> {
                    selectedLocation = latLng;
                    map.clear();
                    map.addMarker(new MarkerOptions().position(latLng));
                });
            });
        }

        submitButton.setOnClickListener(v -> {
            Item item = new Item();
            item.name = nameInput.getText().toString();
            item.comment = commentInput.getText().toString();
            item.rating = ratingBar.getRating();
            item.latitude = selectedLocation.latitude;
            item.longitude = selectedLocation.longitude;
            item.category = categorySpinner.getSelectedItem().toString();

            db.itemDao().insert(item);
            finish();
        });
    }
}