package jp.ac.jec.cm0135.recommap;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.room.Room;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RecomMapActivity extends AppCompatActivity {

    private Chip chipRamen;
    private Chip chipConvenience;
    private Chip chipJEC;
    private Chip chipCafe;
    private Chip chiptouristAttraction;
    private Chip chipSuper;
    private GoogleMap googleMap;
    private AppDatabase db;
    private final Map<Marker, Item> markerItemMap = new HashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_recom_map);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app.db")
                .allowMainThreadQueries().build();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(gMap -> {
                googleMap = gMap;
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(35.6985, 139.6980))
                        .zoom(15.5f)
                        .build();
                googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                registerGoogleMapEvents();
                setCustomInfoWindow();
                showAllMarkers();
            });
        }
        ChipGroup chipGroup = findViewById(R.id.chip_group_item_category);
        chipRamen = findViewById(R.id.chip_ramen);
        chipConvenience = findViewById(R.id.chip_convenience_store);
        chipJEC = findViewById(R.id.chip_jec);
        chipCafe = findViewById(R.id.chip_cafe);
        chipSuper = findViewById(R.id.chip_super);
        chiptouristAttraction = findViewById(R.id.chip_touristAttraction);


        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> showAllMarkers());


        findViewById(R.id.btn_add).setOnClickListener(v -> {
            startActivity(new Intent(this, SpotAddActivity.class));
        });

        findViewById(R.id.btn_delete_all).setOnClickListener(v -> {
            db.itemDao().getAll().forEach(item -> db.itemDao().delete(item));
            googleMap.clear();
            markerItemMap.clear();
            Toast.makeText(this, "全て削除しました", Toast.LENGTH_SHORT).show();
        });
    }

    private void setCustomInfoWindow() {
        googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
            @Override
            public View getInfoWindow(@NonNull Marker marker) {
                return null;
            }

            @Override
            public View getInfoContents(@NonNull Marker marker) {
                View view = getLayoutInflater().inflate(R.layout.custom_info_window, null);

                TextView title = view.findViewById(R.id.title);
                TextView comment = view.findViewById(R.id.comment);
                RatingBar ratingBar = view.findViewById(R.id.ratingBar);

                Item item = markerItemMap.get(marker);

                if (item != null) {
                    title.setText(item.name);
                    comment.setText(item.comment);
                    ratingBar.setRating(item.rating);
                }

                return view;
            }
        });
    }
    private void showAllMarkers() {
        List<Item> items = db.itemDao().getAll();
        googleMap.clear();
        markerItemMap.clear();

        // 💡 Get selected categories
        List<String> selectedCategories = new ArrayList<>();
        if (chipRamen.isChecked()) selectedCategories.add("ラーメン");
        if (chipConvenience.isChecked()) selectedCategories.add("コンビニ");
        if (chipJEC.isChecked()) selectedCategories.add("日本電子専門学校");
        if(chipCafe.isChecked())selectedCategories.add("カフェ");
        if(chipSuper.isChecked())selectedCategories.add("スーパー");
        if(chiptouristAttraction.isChecked())selectedCategories.add("観光地");

        // Show message if none selected
        if (selectedCategories.isEmpty()) {
            Toast.makeText(this, "カテゴリを1つ以上選んでください", Toast.LENGTH_SHORT).show();
            return;
        }

        for (Item item : items) {
            //  Skip if not selected
            if (!selectedCategories.contains(item.category)) continue;

            float color = switch (item.category) {
                case "ラーメン" -> BitmapDescriptorFactory.HUE_RED;
                case "コンビニ" -> BitmapDescriptorFactory.HUE_ORANGE;
                case "日本電子専門学校" -> BitmapDescriptorFactory.HUE_GREEN;
                case "カフェ" -> BitmapDescriptorFactory.HUE_VIOLET;
                case "観光地" -> BitmapDescriptorFactory.HUE_ROSE;
                case "スーパー" -> BitmapDescriptorFactory.HUE_MAGENTA;
                default -> BitmapDescriptorFactory.HUE_BLUE;
            };

            Marker marker = googleMap.addMarker(new MarkerOptions()
                    .title(item.name)
                    .snippet("★" + item.rating + "\n" + item.comment)
                    .position(new LatLng(item.latitude, item.longitude))
                    .icon(BitmapDescriptorFactory.defaultMarker(color))
                    .draggable(false));

            if (marker != null) {
                markerItemMap.put(marker, item);
            }
        }
    }

    private void registerGoogleMapEvents() {
        if (googleMap == null) return;

        googleMap.setOnInfoWindowClickListener(marker -> {
            Item item = markerItemMap.get(marker);
            if (item != null) {
                Intent intent = new Intent(this, SpotEditActivity.class);
                intent.putExtra("item_id", item.id);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (googleMap != null) showAllMarkers();
    }
}
