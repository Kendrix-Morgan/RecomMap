package jp.ac.jec.cm0135.recommap;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity
public class Item {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull public String name;
    @NonNull public String comment;
    public float rating;
    public double latitude;
    public double longitude;
    @NonNull public String category;
}